package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;


public class LoginPage extends ProjectSpecificMethods {
	

	// method name: action+ElementName
	@Given("Enter the username as {string}")
	public LoginPage enterUsername(String username)  {
		driver.findElementByXPath("//input[@id='username']").sendKeys(username);
		return this;
	}

	@Given("Enter the password as {string}")
	public LoginPage enterPassword(String password) {
		driver.findElementById("password").sendKeys(password);
		return this;
	}

	@When("Click on login button")	
	public HomePage clickLoginButtonForPositive() {
		driver.findElementByClassName("decorativeSubmit").click();
		return new HomePage();
	}
	
	public LoginPage clickLoginButtonForNegative() {
		driver.findElementByClassName("decorativeSubmit").click();
		return this;
	}

}
