package pages;

import base.ProjectSpecificMethods;

public class MyLeadsPage extends ProjectSpecificMethods {

}
