package testcase;

import base.ProjectSpecificMethods;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="src/main/java/features/Login.feature",
                 glue="pages",
                 monochrome=true)
				
public class RunnerForLoginFeature extends ProjectSpecificMethods {

}
