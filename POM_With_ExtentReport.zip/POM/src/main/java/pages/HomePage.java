package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Then;

public class HomePage extends ProjectSpecificMethods {
	public HomePage(ChromeDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}
	

	public LoginPage clickLogoutButton() throws IOException {
		try {
			driver.findElementByClassName("decorativeSubmit").click();
			reportStep("logout button clicked successfully", "pass");
		} catch (Exception e) {
			reportStep("logout button clicked successfully", "fail");
		}

		return new LoginPage(driver,node);
	}
	
	@Then("Home page should be displayed")
	public HomePage verifyHomePage() {
		System.out.println("Homepage is displayed");
		return this;
	}

	
}
