package pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;


public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(ChromeDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}

	// method name: action+ElementName
	@Given("Enter the username as {string}")
	public LoginPage enterUsername(String username) throws IOException  {
		
			try {
				driver.findElementById("username").sendKeys(username);
				reportStep(username+" is entered successfully", "pass");
			} catch (Exception e) {
				reportStep(username+" is not entered successfully", "fail");
			}
			
		
		return this;
	}

	@Given("Enter the password as {string}")
	public LoginPage enterPassword(String password) throws IOException {
		try {
			driver.findElementById("password").sendKeys(password);
			reportStep(password+" is entered successfully", "pass");
		} catch (Exception e) {
			reportStep(password+" is not entered successfully", "fail");
		}
		return this;
	}

	@When("Click on login button")	
	public HomePage clickLoginButtonForPositive() throws IOException {
		try {
			driver.findElementByClassName("decorativeSubmit").click();
			reportStep("login button clicked successfully", "pass");
		} catch (Exception e) {
			reportStep("login button clicked successfully", "fail");
		}
		return new HomePage(driver,node);
	}
	
	public LoginPage clickLoginButtonForNegative() {
		driver.findElementByClassName("decorativeSubmit").click();
		return this;
	}

}
