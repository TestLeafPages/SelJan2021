package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.HomePage;
import pages.LoginPage;

public class LoginAndLogout extends ProjectSpecificMethods {
	
	@BeforeTest
	public void setTestDetails() {
		excelFileName = "Credentials";
		testName = "LoginAndLogout";
		testDescription = "Login for LeafTaps";
		testAuthor = " Hari";
		testCategory = "Smoke";

	}
	
	@Test(dataProvider="fetchData")
	public void loginLogout(String username,String password) throws InterruptedException, IOException {
		
	//	LoginPage lp = new LoginPage(driver);
		
		new LoginPage(driver,node)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButtonForPositive()
		.clickLogoutButton();
		
		
		

	}

}
