package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class LoginWithNegativeCredential extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setTestDetails() {
		testName = "LoginWithNegativeCredential";
		testDescription = "Login for LeafTaps using negative data";
		testAuthor = " Hari";
		testCategory = "Smoke";
	}
	
	@Test
	public void loginForNegative() throws InterruptedException, IOException {
		LoginPage lp = new LoginPage(driver,node);
		
		lp.enterUsername("Demosalesmanager")
		.enterPassword("crmsfa123")
		.clickLoginButtonForNegative();

	}

}
