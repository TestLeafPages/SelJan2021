package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Then;

public class HomePage extends ProjectSpecificMethods {
	

	public LoginPage clickLogoutButton() {
		driver.findElementByClassName("decorativeSubmit").click();

		return new LoginPage();
	}

	
}
