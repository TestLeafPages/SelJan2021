package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.ProjectSpecificMethods;


public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage() {
		
		PageFactory.initElements(driver, this);
	}
	
//	@CacheLookup
	@FindBy(how=How.XPATH,using="//input[@class='inputLogin']") List<WebElement> eleUserName;
	
	
	//AND condition
	/*
	 * @FindBys({
	 * 
	 * @FindBy(how=How.ID,using="username"),
	 * 
	 * @FindBy(how=How.XPATH,using="//input[@class='inputLogin123']") } ) WebElement
	 * eleUserName;
	 */
	//OR condition
	/*
	 * @FindAll({
	 * 
	 * @FindBy(how=How.ID,using="username"),
	 * 
	 * @FindBy(how=How.XPATH,using="//input[@class='inputLogin123']") } ) WebElement
	 * eleUserName;
	 */

	// method name: action+ElementName
	public LoginPage enterUsername(String username) throws InterruptedException {
		//driver.findElementByXPath("//input[@id='username']").sendKeys(username);
		
		eleUserName.get(0).sendKeys(username);
		
		//eleUserName.sendKeys(username);
		//Thread.sleep(5000);
		return this;
	}

	@CacheLookup
	@FindBy(how=How.ID,using="password")
	WebElement elePassword;
	
	public LoginPage enterPassword(String password) {
		//driver.findElementById("password").sendKeys(password);
		elePassword.sendKeys(password);
		return this;
	}

	@CacheLookup
	@FindBy(how=How.CLASS_NAME,using="decorativeSubmit")
	WebElement eleLogin;
	
	public HomePage clickLoginButtonForPositive() {
	//	driver.findElementByClassName("decorativeSubmit").click();
		eleLogin.click();
		
		return new HomePage();
	}
	
	public LoginPage clickLoginButtonForNegative() {
	//	driver.findElementByClassName("decorativeSubmit").click();
		eleLogin.click();
		return this;
	}

}
