package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(ChromeDriver driver) {
		
		this.driver = driver;
		
	}

	// method name: action+ElementName
	public LoginPage enterUsername(String username) throws InterruptedException {
		driver.findElementByXPath("//input[@id='username']").sendKeys(username);
		//Thread.sleep(5000);
		return this;
	}

	public LoginPage enterPassword(String password) {
		driver.findElementById("password").sendKeys(password);
		
		return this;
	}

	public HomePage clickLoginButtonForPositive() {
		driver.findElementByClassName("decorativeSubmit").click();
		
		return new HomePage(driver);
	}
	
	public LoginPage clickLoginButtonForNegative() {
		driver.findElementByClassName("decorativeSubmit").click();
		
		return this;
	}

}
