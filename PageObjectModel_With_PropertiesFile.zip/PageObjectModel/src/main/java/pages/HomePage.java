package pages;

import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {
	public HomePage(ChromeDriver driver, Properties prop) {
		
		this.driver = driver;
		this.prop = prop;
		
	}

	public LoginPage clickLogoutButton() {
		driver.findElementByClassName(prop.getProperty("HomePage.LogoutButton.ClassName")).click();

		return new LoginPage(driver,prop);
	}

	public MyHomePage clickCrmsfaLink() {
		driver.findElementByLinkText(prop.getProperty("HomePage.CrmsfaLink.LinkText")).click();

		return new MyHomePage(driver,prop);
	}
	
}
