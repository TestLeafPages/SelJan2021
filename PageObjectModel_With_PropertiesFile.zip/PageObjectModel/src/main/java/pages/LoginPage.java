package pages;

import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	public LoginPage(ChromeDriver driver, Properties prop) {
		
		this.driver = driver;
		this.prop = prop;
		
	}

	// method name: action+ElementName
	public LoginPage enterUsername(String username) throws InterruptedException {
		driver.findElementById(prop.getProperty("LoginPage.Username.Id")).sendKeys(prop.getProperty("username"));
		//Thread.sleep(5000);
		return this;
	}

	public LoginPage enterPassword(String password) {
		driver.findElementById(prop.getProperty("LoginPage.Password.Id")).sendKeys(prop.getProperty("password"));
		
		return this;
	}

	public HomePage clickLoginButtonForPositive() {
		driver.findElementByClassName(prop.getProperty("LoginPage.LoginButton.ClassName")).click();
		
		return new HomePage(driver,prop);
	}
	
	public LoginPage clickLoginButtonForNegative() {
		driver.findElementByClassName(prop.getProperty("LoginPage.LoginButton.ClassName")).click();
		
		return this;
	}

}
