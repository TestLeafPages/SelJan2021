package testcase;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class LoginWithNegativeCredential extends ProjectSpecificMethods{
	
	@Test
	public void loginForNegative() throws InterruptedException {
		LoginPage lp = new LoginPage(driver,prop);
		
		lp.enterUsername("Demosalesmanager")
		.enterPassword("crmsfa123")
		.clickLoginButtonForNegative();

	}

}
